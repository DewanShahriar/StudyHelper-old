 <?php
session_start();
$email = $_POST['email'];
$pass = $_POST['pass'];


$dbhost = "localhost";
$dbuser = "root";
$dbpass = "";
$dbname = "mydb";

// Create connection
$conn = mysqli_connect($dbhost,$dbuser,$dbpass,$dbname);
// Check connection
if (mysqli_connect_error()) {
    die("Connection failed: " . $conn->connect_error);
}



$sql = "SELECT * FROM student where email = '$email' AND pass = '$pass'";
$query = mysqli_query($conn,$sql);




if (mysqli_num_rows($query) > 0) {
    // output data of each row
    while($row = mysqli_fetch_array($query)) {
    	if ($email = row['email'] and $pass = row['pass']) {
            $_SESSION['name']=$row['name'];
            $_SESSION['id']=$row['id'];
            $_SESSION['login'] = true;
    		header("location:home/index.php");
    		
    	} else {
    		echo "error";
    	}
    	
        
    }
} else {
    header("location:index.php");
}
$conn->close();
?> 