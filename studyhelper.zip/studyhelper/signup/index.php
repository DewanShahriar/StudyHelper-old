<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>RegistrationForm_v10 by Colorlib</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">

		<!-- LINEARICONS -->
		<link rel="stylesheet" href="fonts/linearicons/style.css">
		
		<!-- STYLE CSS -->
		<link rel="stylesheet" href="css/style.css">
        
        <style>
            .button {
            background-color: #4CAF50; /* Green */
            border: none;
            color: white;
            padding: 15px 32px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            margin: 4px 2px;
            cursor: pointer;
            }
            .button1 {
                background-color: white; 
                color: black; 
                border: 2px solid #008CBA;
            }
        </style>
	</head>

	<body>
<!--                -------------start------------->
                <?php
        if(isset($_POST['sbtn'])){
            $uname=$uemail=$udob=$upass="";
            
            if(isset($_POST['uname'])) $uname=$_POST['uname'];
            if(isset($_POST['uid'])) $uid=$_POST['uid'];
            if(isset($_POST['uemail'])) $uemail=$_POST['uemail'];
            if(isset($_POST['upass'])) $upass=$_POST['upass'];
            
            
            try{
                $conn=new PDO("mysql:host=localhost;dbname=mydb;",'root','');
                echo "<script>window.alert('connection successful');</script>";
                
                $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            }
            catch(PDOException $e){
                echo "<script>window.alert('connection error');</script>";
            }
            
            try{
                $sqlquery="INSERT INTO student(id,name, email, pass) VALUES('$uid','$uname','$uemail','$upass')";
echo $sqlquery;
                $conn->exec($sqlquery);
                echo "<script>window.alert('insertion successful');</script>";
                echo "<script>location.assign('../index.php')</script>";
            }
            catch(PDOException $e){
                echo "<script>window.alert('query error');</script>";
            }
            
            
        }
    
    ?>
                

		<div class="wrapper">
			<div class="inner">
				<img src="images/image-1.png" alt="" class="image-1">
				<form action="index.php" method="post">
					<h3>New Account?</h3>
					<div class="form-holder">
						<span class="lnr lnr-user"></span>
						<input type="text" class="form-control" placeholder="Username" name="uname">
					</div>
					<div class="form-holder">
						<span class="lnr lnr-envelope"></span>
						<input type="text" class="form-control" placeholder="your id"  name="uid">
					</div>
					<div class="form-holder">
						<span class="lnr lnr-envelope"></span>
						<input type="text" class="form-control" placeholder="Mail" name="uemail">
					</div>
					<div class="form-holder">
						<span class="lnr lnr-lock"></span>
						<input type="password" class="form-control" placeholder="Password" name="upass">
					</div>
					<div class="form-holder">
						<span class="lnr lnr-lock"></span>
						<input type="password" class="form-control" placeholder="Confirm Password" name="upass1">
					</div>
<!--
					<button>
						<span>Register</span>
					</button>
-->

                    <input type="submit" value="Register" class="button button1" name="sbtn" id="reg">
<!--
                    <form action="login/index.html">
                        <button>
						  <span>Log in</span>
					   </button>
                    </form>
-->
                    
				</form>

<!--                -------------end--------------->
				<img src="images/image-2.png" alt="" class="image-2">
			</div>
			
		</div>
		
		<script src="js/jquery-3.3.1.min.js"></script>
		<script src="js/main.js"></script>
        
        
	</body><!-- This templates was made by Colorlib (https://colorlib.com) -->
</html>