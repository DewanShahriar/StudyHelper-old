<?php
        if($_SERVER['REQUEST_METHOD']=="GET"){
            /// nothing to do
        }
        else if($_SERVER['REQUEST_METHOD']=="POST"){
            $uname=$uemail=$udob=$upass="";
            
            
            
            
            if(isset($_POST['uname'])) $uname=$_POST['uname'];
            if(isset($_POST['udob'])) $udob=$_POST['udob'];
            if(isset($_POST['uemail'])) $uemail=$_POST['uemail'];
            if(isset($_POST['upass'])) $upass=$_POST['upass'];
            
            
            try{
                $conn=new PDO("mysql:host=localhost;dbname=mydb;",'root','');
                echo "<script>window.alert('connection successful');</script>";
                
                $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            }
            catch(PDOException $e){
                echo "<script>window.alert('connection error');</script>";
            }
            
            try{
                echo $uname;
                $sqlquery="INSERT INTO student VALUES ('','$uname','$uemail','$upass','$udob','','')";

                $conn->exec($sqlquery);
                echo "<script>window.alert('insertion successful');</script>";
                echo "<script>location.assign('../index.php')</script>";
            }
            catch(PDOException $e){
                echo "<script>window.alert('query error');</script>";
            }
            
            
        }
    
    ?>