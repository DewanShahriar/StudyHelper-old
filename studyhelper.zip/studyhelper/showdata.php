<!DOCTYPE html>

<html>
    <head>
    
    </head>
    
    <body>
        
        <?php
        
        try{
            $conn=new PDO("mysql:host=localhost;dbname=mydb;",'root','');
            $conn->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
            echo "<script>window.alert('database connection successful');</script>";
            
        }
        catch(PDOException $ex){
            echo "<script>window.alert('database connection error');</script>";
        
        }
        
        
        
        ?>
        
        <table style="width:100%;">
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Name</th>
                    <th>DOB</th>
                    <th>Email</th>
                    <th>Address</th>
                    <th>Update/Delete</th>
                </tr>
            
            </thead>
            
            <tbody>
                
                
                
                
                <?php
                    
                    ////deleting
                    if(isset($_GET['id'])){
                        $delquery="DELETE FROM student WHERE id=".$_GET['id'];
                        
                        $conn->exec($delquery);
                        echo "<script>window.alert('database delete successful');</script>";
                    }
                    
                    try{
                        $sqlquery="SELECT * FROM student";
                        $pdostmt=$conn->query($sqlquery);
                        $table=$pdostmt->fetchAll();
                        
                        foreach($table as $row){
                            ?>
                            <tr>
                                <td><?php echo $row[0] ?></td>
                                <td><?php echo $row[1] ?></td>
                                <td><?php echo $row[2] ?></td>
                                <td><?php echo $row[3] ?></td>
                                <td><?php echo $row[4] ?></td>
                                <td><input type="button" value="Update">
                                    <input type="button" value="Delete" onclick="deleterow(<?php echo $row[0] ?>);">
                                </td>
                            </tr>
                    <?php
                        }
                    }
                    catch(PDOException $ex){
                        echo "<script>window.alert('database sql query error');</script>";
                    }
                
                ?>
                
                <script>
                    function deleterow(id){
                        window.location.assign("showdata.php?id="+id);
                        
                    }
                
                </script>
            
            </tbody>
        
        
        
        </table>
    
    
    
    
    </body>




</html>