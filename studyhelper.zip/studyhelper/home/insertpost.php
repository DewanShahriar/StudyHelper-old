<?php
        if($_SERVER['REQUEST_METHOD']=="POST"){
            /// nothing to do
            //echo "i am here";
//            $userid=$sharedata=$date='';
//            
//            if(isset($_POST['userid'])){
//                echo "userid found";
//                $userid=$_POST['userid'];
//                echo "$userid";
//            } 
//            if(isset($_POST['sharedata'])) $sharedata=$_POST['sharedata'];
            
            $data=json_decode(file_get_contents('php://input'),true);
            
            
            var_dump($data);
            echo "end";
            
            $date = date("Y-m-d");
            $sharedata = $data['item1'];
            $userid= $data['item2'];
            
            
            
            
            
            try{
                $conn=new PDO("mysql:host=localhost;dbname=mydb;",'root','');
                echo "<script>window.alert('connection successful');</script>";
                
                $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            }
            catch(PDOException $e){
                echo "<script>window.alert('connection error');</script>";
            }
            
            try{
                $sqlquery="INSERT INTO post VALUES ('','$userid','$date','$sharedata')";

                $conn->exec($sqlquery);
                echo "<script>window.alert('insertion successful');</script>";
            }
            catch(PDOException $e){
                echo "<script>window.alert('query error');</script>";
            }
            
        }
        else if($_SERVER['REQUEST_METHOD']=="GET"){
            $sid=$post=$semail=$sdob=$saddress="";
            
            $date = date("Y-m-d");
            
            
            if(isset($_POST['sharedata'])) $post=$_GET['sharedata'];
            if(isset($_POST['userid'])) $sid=$_GET['userid'];
            echo $sid;
            
            try{
                $conn=new PDO("mysql:host=localhost;dbname=mydb;",'root','');
                echo "<script>window.alert('connection successful');</script>";
                
                $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            }
            catch(PDOException $e){
                echo "<script>window.alert('connection error');</script>";
            }
            
            try{
                $sqlquery="INSERT INTO post VALUES ('','$userid','$date','$post')";

                $conn->exec($sqlquery);
                echo "<script>window.alert('insertion successful');</script>";
            }
            catch(PDOException $e){
                echo "<script>window.alert('query error');</script>";
            }
            
            
        }
    
    ?>