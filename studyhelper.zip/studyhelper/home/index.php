<!DOCTYPE html>

<?php
 session_start();
$username=$_SESSION['name'];
$userid = $_SESSION['id'];
$login = $_SESSION['login'];




$dbhost = "localhost";
$dbuser = "root";
$dbpass = "";
$dbname = "mydb";

//// Create connection
//$conn = mysqli_connect($dbhost,$dbuser,$dbpass,$dbname);
//// Check connection
//if (mysqli_connect_error()) {
//    die("Connection failed: " . $conn->connect_error);
//}

try{
            $conn=new PDO("mysql:host=localhost;dbname=mydb;",'root','');
            $conn->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
//            echo "<script>window.alert('database connection successful');</script>";
            
        }
        catch(PDOException $ex){
            echo "<script>window.alert('database connection error');</script>";
        
        }

try{
                $sqlquery="SELECT * FROM student where id = '$userid' ";
                $pdostmt=$conn->query($sqlquery);
                $table=$pdostmt->fetchAll();
                
///           echo "<script>window.alert('successful');</script>";
            }
            catch(PDOException $e){
                echo "<script>window.alert('query error');</script>";
            }


?>

<?php
if($login==true){

?>
<html lang="en">
  <head>
    <title>StudyHelper</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Lora:400,400i,700,700i&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Abril+Fatface&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
      <link rel="icon" href="../images/logo1.PNG">
  </head>
  <body>

	<div id="colorlib-page">
		<a href="#" class="js-colorlib-nav-toggle colorlib-nav-toggle"><i></i></a>
		<aside id="colorlib-aside" role="complementary" class="js-fullheight">
			<nav id="colorlib-main-menu" role="navigation">
                <a href="single.html" class="img img-2" style="background-image: url(images/image_1.jpg);"></a>
				<ul>
					<li class="colorlib-active"><a href="index.html">Home</a></li>
					<li><a href="profile.php">Profile</a></li>
<!--					<li><a href="#">Notifications</a></li>-->
<!--					<li><a href="#">Add Course</a></li>-->
                    <li><a href="../logout.php">Log out</a></li>
                    <li><img src="<?php echo $table[0]['propic'] ?>" alt="profile pic" style="width:150px;height:150px;border-radius: 50%;"></li>
				</ul>
			</nav>

			<div class="colorlib-footer">
                    

                    <h1 id="colorlib-logo" class="mb-4"><a href="index.php" style="background-image: url(images/bg_1.jpg);">
                        <?php echo $username ?><span></span></a></h1>
				<div class="mb-4">
					<h3></h3>
                    <a href="single.html" class="img img-2" style="background-image: url(images/image_1.jpg);"></a>
					<form action="index.php" class="colorlib-subscribe-form" method="post">
            <div class="form-group d-flex">
            	<div class="icon"><span class=""></span></div>
              <input type="text" class="form-control" placeholder="Share your feelings" name="post" id="share">
                <input type="button" value="Post" onclick='ajaxfn(<?php echo $userid ?>)'>
            </div>
          </form>
<!--                    start insert post-->
                    
<!--
                    <?php
//        if($_SERVER['REQUEST_METHOD']=="GET"){
//            /// nothing to do
//        }
//        else if($_SERVER['REQUEST_METHOD']=="POST"){
//            $sid=$post=$semail=$sdob=$saddress="";
//            
//            $date = date("Y-m-d");
//            
//            
//            if(isset($_POST['post'])) $post=$_POST['post'];
//            
//            
//            try{
//                $conn=new PDO("mysql:host=localhost;dbname=mydb;",'root','');
//                //echo "<script>window.alert('connection successful');</script>";
//                
//                $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
//            }
//            catch(PDOException $e){
//                echo "<script>window.alert('connection error');</script>";
//            }
//            
//            try{
//                $sqlquery="INSERT INTO post VALUES ('','$userid','$date','$post')";
//
//                $conn->exec($sqlquery);
//                //echo "<script>window.alert('insertion successful');</script>";
//            }
//            catch(PDOException $e){
//                echo "<script>window.alert('query error');</script>";
//            }
//            
//            
//        }
    
    ?>
-->
                  
<!--                  end   insert post-->
				</div>
				<p class="pfooter"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
	  Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved |  <i class="icon-heart" aria-hidden="true"></i> by <a href="#" target="_blank">Dewan Shahriar Rahman</a>
	  <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
			</div>
		</aside> <!-- END COLORLIB-ASIDE -->
		<div id="colorlib-main">
			<section class="ftco-section ftco-no-pt ftco-no-pb">
	    	<div class="container">
	    		<div class="row d-flex">
	    			<div class="col-xl-8 py-5 px-md-5">
	    				<div class="row pt-md-4">
                        
<!--                            start from here-->
                            
                            <?php
                    
                    
                    try{
                        $sqlquery="SELECT * FROM post join student on student.id = post.uid ORDER BY pdate DESC";
                        $pdostmt=$conn->query($sqlquery);
                        $table=$pdostmt->fetchAll();
                        
                        foreach($table as $row){
                            ?>
                            
                            
			    			<div class="col-md-12">
									<div class="blog-entry ftco-animate d-md-flex">
										<a href="#" class="img img-2" style="background-image: url(<?php echo $row['propic'] ?>);"></a>
										<div class="text text-2 pl-md-4">
				              <h3 class="mb-2"><a href="#" ><?php echo $row['name'] ?></a></h3>
				              <div class="meta-wrap">
												<p class="meta">
				              		<span><i class="icon-calendar mr-2"></i><?php echo $row[2] ?></span>
				              		<span><a href="#"><i class="icon-folder-o mr-2"></i>Travel</a></span>
				              		<span><i class="icon-comment2 mr-2"></i>5 Comment</span>
				              	</p>
			              	</div>
				              <p class="mb-4"><?php echo $row[3] ?></p>
				              <p><a href="#" class="btn-custom">Read Comment <span class="ion-ios-arrow-forward"></span></a></p>
				            </div>
									</div>
								</div>
                            
                            <?php
                        }
                    }
                    catch(PDOException $ex){
                        echo "<script>window.alert('database sql query error');</script>";
                    }
                
                ?>
                        
<!--                            end here-->
								
			    		</div><!-- END-->
			    		<div class="row">
			          <div class="col">
			            <div class="block-27">
			              <ul>
			                <li><a href="#">&lt;</a></li>
			                <li class="active"><span>1</span></li>
			                <li><a href="#">2</a></li>
			                <li><a href="#">3</a></li>
			                <li><a href="#">4</a></li>
			                <li><a href="#">5</a></li>
			                <li><a href="#">&gt;</a></li>
			              </ul>
			            </div>
			          </div>
			        </div>
			    	</div>
	    			<div class="col-xl-4 sidebar ftco-animate bg-light pt-5">
	            <div class="sidebar-box pt-md-4">
	              <form action="#" class="search-form">
	                <div class="form-group">
	                  <span class=""></span>
	                  <input type="text" class="form-control" placeholder="Type a description" id="des">
                        <select class="form-control" id="drpdwn">
                            <option value="none" selected>None</option>
                            <?php
                    
                    
                    try{
                        $sqlquery="SELECT * FROM course join student on student.id = course.uid where student.id = '$userid'";
                        $pdostmt=$conn->query($sqlquery);
                        $table=$pdostmt->fetchAll();
                        
                        foreach($table as $row){
                            ?>
                            <option value="<?php echo $row['ccode'] ?>"><?php echo $row['cname'] ?></option>
                            <?php
                        }
                    }
                    catch(PDOException $ex){
                        echo "<script>window.alert('database sql query error');</script>";
                    }
                
                ?>
                        </select>
                        <input type="button" class="form-control" value="send" onclick='ajaxfntn(<?php echo $userid ?>)'>
                        
	                </div>
	              </form>
	            </div>
	            <div class="sidebar-box ftco-animate">
	            	<h3 class="sidebar-heading">My Courses</h3>
                    <?php
                    
                    
                    try{
                        $sqlquery="SELECT * FROM course INNER join student on student.id = course.uid where student.id = '$userid'";
                        $pdostmt=$conn->query($sqlquery);
                        $table=$pdostmt->fetchAll();
                        
                        foreach($table as $row){
                            ?>
	              <ul class="categories">
	                <li><a href="#"><?php echo $row['cname'] ?><span></span></a></li>
	                
	              </ul>
                    <?php
                        }
                    }
                    catch(PDOException $ex){
                        echo "<script>window.alert('database sql query error');</script>";
                    }
                
                ?>
	            </div>

	            <div class="sidebar-box ftco-animate">
	              <h3 class="sidebar-heading">Requests</h3>
<!--                    //////////-->
                    <?php
                    
                    
                    try{
                        $sqlquery="SELECT * FROM request join student on student.id = request.uidreceiver where request.uidreceiver = '$userid';";
                        $pdostmt=$conn->query($sqlquery);
                        $table=$pdostmt->fetchAll();
                        
                        foreach($table as $row){
                            ?>
	              <div class="block-21 mb-4 d-flex">
<!--	                <a class="blog-img mr-4" style="background-image: url(images/image_1.jpg);"></a>-->
	                <div class="text">
	                  <h3 class="heading"><a href="#"><?php echo $row['des'] ?></a></h3>
	                  <div class="meta">
	                    <div><a href="#"><span class="icon-calendar"></span><?php echo $row['rdate'] ?></a></div>
	                    <div><a href="#"><span class="icon-person"></span><?php echo $row['uidsender'] ?></a></div>
	                    <div><a href="#"><span class="icon-chat"></span><?php echo $row['ccode'] ?></a></div>
	                  </div>
	                </div>
	              </div>
                    <?php
                        }
                    }
                    catch(PDOException $ex){
                        echo "<script>window.alert('database sql query error');</script>";
                    }
//                
                ?>
<!--                    /////////-->
                    
	              
	            </div>

	            <div class="sidebar-box ftco-animate">
	              <h3 class="sidebar-heading">Notifications</h3>
	              <ul class="tagcloud">
<!--
	                <a href="#" class="tag-cloud-link">animals</a>
	                <a href="#" class="tag-cloud-link">human</a>
	                <a href="#" class="tag-cloud-link">people</a>
	                <a href="#" class="tag-cloud-link">cat</a>
	                <a href="#" class="tag-cloud-link">dog</a>
	                <a href="#" class="tag-cloud-link">nature</a>
	                <a href="#" class="tag-cloud-link">leaves</a>
	                <a href="#" class="tag-cloud-link">food</a>
-->
	              </ul>
	            </div>

							<div class="sidebar-box subs-wrap img py-4" style="background-image: url(images/bg_1.jpg);">
								<div class="overlay"></div>
								<h3 class="mb-4 sidebar-heading">Newsletter</h3>
								<p class="mb-4">Far far away, behind the word mountains, far from the countries Vokalia</p>
	              <form action="#" class="subscribe-form">
	                <div class="form-group">
	                  <input type="text" class="form-control" placeholder="Email Address">
	                  <input type="submit" value="Subscribe" class="mt-2 btn btn-white submit">
	                </div>
	              </form>
	            </div>

	            <div class="sidebar-box ftco-animate">
	            	<h3 class="sidebar-heading">Archives</h3>
	              <ul class="categories">
	              	<li><a href="#">Decob14 2018 <span>(10)</span></a></li>
	                <li><a href="#">September 2018 <span>(6)</span></a></li>
	                <li><a href="#">August 2018 <span>(8)</span></a></li>
	                <li><a href="#">July 2018 <span>(2)</span></a></li>
	                <li><a href="#">June 2018 <span>(7)</span></a></li>
	                <li><a href="#">May 2018 <span>(5)</span></a></li>
	              </ul>
	            </div>


	            <div class="sidebar-box ftco-animate">
	              <h3 class="sidebar-heading">Paragraph</h3>
	              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ducimus itaque, autem necessitatibus voluptate quod mollitia delectus aut.</p>
	            </div>
	          </div><!-- END COL -->
	    		</div>
	    	</div>
	    </section>
		</div><!-- END COLORLIB-MAIN -->
	</div><!-- END COLORLIB-PAGE -->

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>
      
      <script>
                        var share = document.getElementById('share');
                        var btn = document.getElementById('btn');
                        
//                        btn.addEventListener('click', ajaxfn);
                        console.log("error1");
                        function ajaxfn(id){
                            console.log("error2");
                            var ajaxreq = new XMLHttpRequest();
                            
                            ajaxreq.open('POST','insertpost.php');
                           
                            var jsobject={"item1":share.value, "item2":id};
                            
                            
                            ajaxreq.send(JSON.stringify(jsobject) );
                            alert("Successfully posted please reload this page");
                        }
                        
                    </script>
<!--      request-->
      <script>
                        var des = document.getElementById('des');
                        var course = document.getElementById('drpdwn');
                        
//                        btn.addEventListener('click', ajaxfn);
                        //console.log("error1");
                        function ajaxfntn(id){
                            //console.log("error2");
                            var ajaxreq = new XMLHttpRequest();
                            
                            ajaxreq.open('POST','reqprocess.php');
                           
                            var jsobject={"item1":des.value, "item2":id, "item3":course.value};
                            
                            
                            ajaxreq.send(JSON.stringify(jsobject) );
                            alert("Request has been sent");
                        }
                        
                    </script>
    
  </body>
</html>

<?php
}
else{
    header("location:../index.php");
}
    
?>


