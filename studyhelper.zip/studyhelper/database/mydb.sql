-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 24, 2019 at 08:39 PM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mydb`
--

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `sid` int(11) NOT NULL,
  `uid` int(11) DEFAULT NULL,
  `ccode` int(11) DEFAULT NULL,
  `cname` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`sid`, `uid`, `ccode`, `cname`) VALUES
(1, 1, 465, 'Web Programming'),
(2, 1, 415, 'Pattern Recognition'),
(3, 1, 421, 'Computer Graphics'),
(4, 2, 465, 'Web Programming'),
(5, 5, 477, 'Network Security'),
(6, 1, 111, 'Accounting'),
(8, 5, 421, 'Computer Graphics'),
(9, 5, 415, 'Pattern Recognition'),
(10, 151, 415, 'Pattern Recognition'),
(11, 4, 415, 'Pattern Recognition'),
(15, 2, 111, 'Accounting'),
(18, 227, 321, 'Software Engineering'),
(19, 151, 321, 'Software Engineering'),
(20, 4, 321, 'Software Engineering'),
(21, 239, 421, 'Computer Graphics'),
(22, 227, 421, 'Computer Graphics');

-- --------------------------------------------------------

--
-- Table structure for table `post`
--

CREATE TABLE `post` (
  `pid` int(11) NOT NULL,
  `uid` int(11) DEFAULT NULL,
  `pdate` date DEFAULT NULL,
  `pdes` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `post`
--

INSERT INTO `post` (`pid`, `uid`, `pdate`, `pdes`) VALUES
(1, 1, '2019-07-02', 'hi i am doing well'),
(2, 2, '2019-07-03', 'i am sajib'),
(3, 3, '2019-07-17', 'i am from bhanga'),
(4, 4, '2019-07-30', 'my door is always open for all, so feel to leave.'),
(5, 4, '2019-07-31', 'The following SQL statement selects all customers from the \"Customers\" table, sorted by the \"Country\" and the \"CustomerName\" column. This means that it orders by Country, but if some rows have the same Country, it orders them by CustomerName:'),
(21, 2, '2019-08-03', 'Machine learning is an application of artificial intelligence (AI) that provides systems the ability to automatically learn and improve from experience without being explicitly programmed. Machine learning focuses on the development of computer programs that can access data and use it learn for themselves.'),
(22, 2, '2019-08-24', 'Tomorrow will no classes');

-- --------------------------------------------------------

--
-- Table structure for table `request`
--

CREATE TABLE `request` (
  `rid` int(11) NOT NULL,
  `uidsender` int(11) DEFAULT NULL,
  `uidreceiver` int(11) DEFAULT NULL,
  `ccode` int(11) DEFAULT NULL,
  `des` text,
  `status` varchar(10) DEFAULT NULL,
  `rdate` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `request`
--

INSERT INTO `request` (`rid`, `uidsender`, `uidreceiver`, `ccode`, `des`, `status`, `rdate`) VALUES
(4, 1, 2, 465, 'php', NULL, '2019-08-24'),
(6, 1, 5, 465, 'php', NULL, '2019-08-24'),
(7, 3, 2, 421, 'line clip', NULL, '2019-08-24'),
(12, 2, 1, 465, 'ajax', NULL, NULL),
(13, 1, 5, 415, 'knn', NULL, NULL),
(15, 1, 4, 415, 'knn', NULL, NULL),
(18, 1, 4, 415, 'knn', NULL, NULL),
(19, 5, 1, 421, 'cohen', NULL, NULL),
(20, 5, 1, 421, 'shatherland', NULL, '2019-08-24'),
(21, 1, 2, 111, 'cost', NULL, '2019-08-24'),
(22, 227, 151, 321, 'agaile', NULL, '2019-08-24'),
(23, 227, 4, 321, 'agaile', NULL, '2019-08-24');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `email` varchar(30) DEFAULT NULL,
  `pass` varchar(30) NOT NULL,
  `dob` date NOT NULL,
  `propic` varchar(30) NOT NULL,
  `address` varchar(150) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`id`, `name`, `email`, `pass`, `dob`, `propic`, `address`) VALUES
(0, 'akash', 'akash@gmail.com', '1234', '2019-08-07', 'pro_pic/akash.jpg', 'rangpur'),
(1, 'shan', 'shan@gmail.com', '1234', '2019-07-03', 'pro_pic/shaan.jpg', 'sayednagar'),
(2, 'sajib', 'sajib@gmail.com', '1234', '2019-06-03', 'pro_pic/sajib.jpg', 'jamalpur'),
(3, 'prince', 'prince@gmail.com', '1234', '2019-07-02', 'pro_pic/prince.jpg', 'vanga'),
(4, 'tuhin', 'tuhin@gmail.com', '1234', '2019-07-12', 'pro_pic/tuhin.jpg', 'sayednagar'),
(5, 'swapnil', 'swapnil@gmail.com', '1234', '2019-08-31', 'pro_pic/swapnil.jpg', 'sayednagar'),
(151, 'salman', 'salman@gmail.com', '1234', '2019-08-01', 'pro_pic/salman.jpg', 'mdpur'),
(227, 'shohag', 'shohag@gmail.com', '1234', '2019-08-01', 'pro_pic/shohag.jpg', 'tongi'),
(239, 'sharif', 'sharif@gmail.com', '1234', '2019-08-02', 'pro_pic/sharif.jpg', 'mirpur');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`sid`),
  ADD KEY `uid` (`uid`);

--
-- Indexes for table `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`pid`),
  ADD KEY `uid` (`uid`);

--
-- Indexes for table `request`
--
ALTER TABLE `request`
  ADD PRIMARY KEY (`rid`),
  ADD KEY `uidsender` (`uidsender`),
  ADD KEY `uidreceiver` (`uidreceiver`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `course`
--
ALTER TABLE `course`
  MODIFY `sid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `post`
--
ALTER TABLE `post`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `request`
--
ALTER TABLE `request`
  MODIFY `rid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `course`
--
ALTER TABLE `course`
  ADD CONSTRAINT `course_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `student` (`id`);

--
-- Constraints for table `post`
--
ALTER TABLE `post`
  ADD CONSTRAINT `post_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `student` (`id`);

--
-- Constraints for table `request`
--
ALTER TABLE `request`
  ADD CONSTRAINT `request_ibfk_1` FOREIGN KEY (`uidsender`) REFERENCES `student` (`id`),
  ADD CONSTRAINT `request_ibfk_2` FOREIGN KEY (`uidreceiver`) REFERENCES `student` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
