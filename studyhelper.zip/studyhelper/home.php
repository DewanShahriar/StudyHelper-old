﻿<!DOCTYPE html>

<html lang="en">
<head>
  <title>Study Helper</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <style>    
    /* Set black background color, white text and some padding */
    footer {
      background-color: #555;
      color: white;
      padding: 15px;
    }
    p {
    text-align: left;
}

  </style>
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="home.php">Study Helper</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active"><a href="home.php">Home</a></li>
        <li><a href="sendrequest.php">Send Request</a></li>
        <li><a href="received.php">Received Request</a></li>
      </ul>
      <form class="navbar-form navbar-right" role="search">
        <div class="form-group input-group">
          <input type="text" class="form-control" placeholder="Search..">
          <span class="input-group-btn">
            <button class="btn btn-default" type="button">
              <span class="glyphicon glyphicon-search"></span>
            </button>
          </span>        
        </div>
      </form>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="#"><span class="glyphicon glyphicon-user"></span> My Account</a></li>
      </ul>
    </div>
  </div>
</nav>
  
<div class="container text-center">    
  <div class="row">
    <div class="col-sm-3 well">
      <div class="well">
        <h3><a href="#">My Profile</a></h3>
        <img src="images.jpg" class="img-circle" height="100" width="100" alt="Avatar">
	<h4></h4>
      </div>
      <div class="profile">
        <h3><a href="#">About me</a></h3>
          <h4></h4>
        
      </div>
      <div class="bios">
        <h3><a href="#">My Course</a></h3>
      </div>
      <ul class="list-group">
  <li class="list-group-item">CSI 221</li>
  <li class="list-group-item">CSI 228</li>
  <li class="list-group-item">CSE 315</li>
  <li class="list-group-item">CSE 316</li>
</ul>
<div class="custom-select" style="width:200px;">
  <select>
    <option value="0">Select Course:</option>
    <option value="1">CSI 121</option>
    <option value="2">CSI 122</option>
    <option value="3">CSI 123</option>
    <option value="4">CSI 124</option>
    <option value="5">CSI 125</option>
    <option value="6">CSI 126</option>
    <option value="7">CSE 312</option>
    <option value="8">CSE 313</option>
    <option value="9">CSE 314</option>
    <option value="10">CSE 315</option>
    <option value="11">CSE 316</option>
    <option value="12">CSE 317</option>
  </select>
</div>
<button type="button" class="btn btn-primary">Add</button>
    </div>
    <div class="col-sm-7">
    
      <div class="row">
        <div class="col-sm-12">
          <div class="panel panel-default text-left">
            <div class="panel-body">
              <p contenteditable="true">write your post
                <input type="text" id ="user" name ="write"/></p>
              <button type="button" class="btn btn-default btn-sm">
                <span class=""></span> post
              </button> 
               
            </div>
          </div>
        </div>
      </div>
      
      <div class="row">
        <div class="col-sm-3">
          <div class="well">
           
           <img src="image1.jpg" class="img-circle" height="55" width="55" alt="Avatar">
           <h4>
            

          </h4>
          </div>
        </div>
        <div class="col-sm-9">
          <div class="well">
            <p> 
              
            </p>
          <p><a href="#">See comments</a></p>
          </div>
          <div class="well">
            <input type="text" class="form-control" id="usr">
            <button type="button" class="btn btn-primary">Comment</button>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-sm-3">
          <div class="well">
           
           <img src="image2.jpg" class="img-circle" height="55" width="55" alt="Avatar">
           <h4>
            
           </h4>
          </div>
        </div>
        <div class="col-sm-9">
          <div class="well">
            <p>
              
               </p>
          <p><a href="#">See comments</a></p>
          </div>
          <div class="well">
            <input type="text" class="form-control" id="usr">
            <button type="button" class="btn btn-primary">Comment</button>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-sm-3">
          <div class="well">
           
           <img src="image3.jpg" class="img-circle" height="55" width="55" alt="Avatar">
           <h4>
            
           </h4>
          </div>
        </div>
        <div class="col-sm-9">
          <div class="well">
            <p> 
              
            </p>
          <p><a href="#">See comments</a></p>
          </div>
          <div class="well">
            <input type="text" class="form-control" id="usr">
            <button type="button" class="btn btn-primary">Comment</button>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-sm-3">
          <div class="well">
           
           <img src="image4.jpg" class="img-circle" height="55" width="55" alt="Avatar">
           <h4>
            
           </h4>
          </div>
        </div>
        <div class="col-sm-9">
          <div class="well">
            <p>
              
             </p>
          <p><a href="#">See comments</a></p>
          </div>
          <div class="well">
            <input type="text" class="form-control" id="usr">
            <button type="button" class="btn btn-primary">Comment</button>
          </div>
        </div>
      </div>     
    </div>
    <div class="col-sm-2 well">
      <h3><a href="#">Notifications</a></h3>     
      <div class="noti">
        
      </div>
      
      </div>
      <div class="col-sm-2 well">
      <h3><a href="accepted.php">Accepted</a></h3>     
      <div class="noti">
        
      </div>
      
      </div>
    </div>
  </div>
</div>


</footer>

</body>
</html>
